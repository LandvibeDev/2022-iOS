//
//  ThemeMemoryGame.swift
//  Memorize
//
//  Created by Kyungsoo Lee on 2022/08/02.
//

import SwiftUI

class ThemeMemoryGame: ObservableObject {
    
    @Published var themeGame = createThemeMemoryGame(getRandomTheme())
    var cards: [MemoryGame<String>.Card] {
        themeGame.cards
    }
    
    static let emojis = getRandomTheme().getEmojis()
    
    static func getNumberOfCardPairs() -> Int {
        return 2 * Int.random(in: 1...5)
    }
    
    static func createThemeMemoryGame(_ theme: Theme) -> MemoryGame<String> {
        MemoryGame<String>(numberOfPairsOfCard: (Int.random(in: 1...5)), theme: theme) { pairIndex in emojis[pairIndex] }
    }
    
    static func getRandomTheme() -> Theme {
        return Theme.allCases.randomElement()!
    }
    
    func getTheme() -> Theme {
        return themeGame.theme
    }

    func choose(_ card: MemoryGame<String>.Card) {
        themeGame.choose(card)
    }
    
}
