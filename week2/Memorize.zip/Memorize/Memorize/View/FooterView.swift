//
//  FooterView.swift
//  Memorize
//
//  Created by Kyungsoo Lee on 2022/08/05.
//

import SwiftUI

struct FooterView: View {
    @EnvironmentObject var viewModel: ThemeMemoryGame
    var body: some View {
        Button {
//            ThemeMemoryGame.createThemeMemoryGame(viewModel.)
        } label: {
            Text("New Game")
                .foregroundColor(.red)
        }
    }
}

struct FooterView_Previeaws: PreviewProvider {
    static var previews: some View {
        FooterView()
    }
}
