//
//  PointView.swift
//  Memorize
//
//  Created by Kyungsoo Lee on 2022/08/05.
//

import SwiftUI

struct PointView: View {
    var body: some View {
        Text("Points: ~")
            .foregroundColor(.red)
    }
}

struct PointView_Previews: PreviewProvider {
    static var previews: some View {
        PointView()
    }
}
