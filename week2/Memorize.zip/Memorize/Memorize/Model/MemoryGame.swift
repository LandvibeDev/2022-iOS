//
//  MemoryGame.swift
//  Memorize
//
//  Created by Kyungsoo Lee on 2022/08/02.
//

import Foundation

struct MemoryGame<CardContent> {
    
    var theme: Theme
    var cards: [Card]
    var point: Int
    var countOfOpenCards: Int
    
    init(numberOfPairsOfCard: Int, theme: Theme, createContent: (Int) -> CardContent) {
        cards = [Card]()
        
        self.theme = theme;
        self.point = 0
        self.cards = cards.shuffled()
        countOfOpenCards = 0
        
        for pairIndex in 0 ..< numberOfPairsOfCard {
            let content = createContent(pairIndex)
            cards.append(Card(content: content, id: 2 * pairIndex))
            cards.append(Card(content: content, id: 2 * pairIndex + 1))
        }
    }
    
    
    mutating func choose(_ card: Card) {
        if let chosenIndex = cards.firstIndex(where: {$0.id == card.id }) {
            if(countOfOpenCards == 0) {
                cards[chosenIndex].isFaceUp.toggle()
                countOfOpenCards += 1
            }
            else if(countOfOpenCards == 1) {
                cards[chosenIndex].isFaceUp.toggle()
                countOfOpenCards = 0
//                if(cards[])
                
            }
        }
    }
    
    func getTheme() -> Theme {
        return theme
    }
    
    

    struct Card: Identifiable {
        var isFaceUp = true
        var isMatched = false
        var isOpened = false
        var content: CardContent
        var id: Int
    }
}
