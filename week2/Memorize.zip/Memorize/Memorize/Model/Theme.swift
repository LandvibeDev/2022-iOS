//
//  Theme.swift
//  Memorize
//
//  Created by Kyungsoo Lee on 2022/08/07.
//

import Foundation

enum Theme: String, CaseIterable {
    case Halloween = "Halloween"
    case Sports = "Sports"
    case Nature = "Nature"
    case Animal = "Animal"
    case Vehicle = "Vehicle"
    case Face = "Face"
    case Flag = "Flag"
    
    enum Color {
        case orange
        case blue
        case green
        case yellow
        case red
        case purple
        case cyan
        case black
    }
    
    func getTitle() -> String {
        switch self {
        case .Halloween:
            return "Halloween"
        case .Sports:
            return "Sports"
        case .Nature:
            return "Nature"
        case .Animal:
            return "Animal"
        case .Vehicle:
            return "Vehicle"
        case .Face:
            return "Face"
        case .Flag:
            return "Flag"
        }
    }
    
    func getColor() -> Color {
        switch self {
        case .Halloween:
            return .orange
        case .Sports:
            return .blue
        case .Nature:
            return .green
        case .Animal:
            return .yellow
        case .Vehicle:
            return .red
        case .Face:
            return .purple
        case .Flag:
            return .cyan
        }
    }
    
    func getEmojis() -> [String] {
        switch self {
        case .Halloween:
            return ["🎃", "💀", "👻", "☠️", "🤡", "👹", "👺"].shuffled()
        case .Sports:
            return ["🥎", "🏀", "🏈", "⚽️", "⚾️", "🏐"].shuffled()
        case .Nature:
            return ["🌲", "🌳", "🌱", "🌴", "🌵", "🍁", "🌿", "🍂"].shuffled()
        case .Animal:
            return ["🙊", "🦔", "🐨", "🐋", "🐕", "🦈"].shuffled()
        case .Vehicle:
            return ["🚗", "🚑", "🚝", "🚒", "🚎", "🚁"].shuffled()
        case .Face:
            return ["👸", "🎅", "👴", "👦"].shuffled()
        case .Flag:
            return ["🇰🇷", "🇺🇸", "🇯🇵", "🇨🇳", "🇨🇦", "🇧🇪", "🇬🇪", "🏴󠁧󠁢󠁳󠁣󠁴󠁿", "🇬🇧", "🇧🇷"].shuffled()
        }
    }
}






